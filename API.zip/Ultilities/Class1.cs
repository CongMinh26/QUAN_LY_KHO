﻿using System;

namespace Ultilities
{
    public class Class1
    {
    }
}
