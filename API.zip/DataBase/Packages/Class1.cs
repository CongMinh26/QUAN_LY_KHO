﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataBase.Packages
{
    class Class1
    {
        /*
        Microsoft.AspNetCore.Identity
        Microsoft.AspNetCore.Identity.EntityFrameworkCore
        Microsoft.EntityFrameworkCore.Design
        Microsoft.EntityFrameworkCore.SqlServer
        Microsoft.EntityFrameworkCore.Tools
        Microsoft.Extensions.Configuration
        Microsoft.Extensions.Configuration.FileExtensions
        Microsoft.Extensions.Configuration.Json
        */
    }
}
