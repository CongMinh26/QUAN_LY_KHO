﻿using System;

namespace DataBase
{
    public class Class1
    {
        // Microsoft.AspNetCore.Http
        // FluentValidation.AspNetCore
    }
}
