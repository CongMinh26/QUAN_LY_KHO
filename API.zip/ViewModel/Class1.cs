﻿using System;

namespace ViewModel
{
    public class Class1
    {
        // Microsoft.AspNetCore.Http
        // FluentValidation.AspNetCore
    }
}
