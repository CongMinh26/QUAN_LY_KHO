﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModel.User
{
    public class DeleteRequest
    { 
        public string MANV { get; set; }
    }
}
