﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModel.User
{
    class RegisterRequestValidator
    {
    }
}
